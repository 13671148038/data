$.ajaxSetup({
    //设置ajax请求结束后的执行动作
    complete: function (XMLHttpRequest, textStatus) {
        // 通过XMLHttpRequest取得响应头，sessionstatus
        try {
            var REDIRECT = XMLHttpRequest.getResponseHeader("REDIRECT");
            if (REDIRECT == "REDIRECT") {
                var win = window;
                while (win != win.top) {
                    win = win.top;
                }
                win.location.href = XMLHttpRequest.getResponseHeader("CONTENTPATH");
            }
            var AUTHENTICATION = XMLHttpRequest.getResponseHeader("AUTHENTICATION");
            if (AUTHENTICATION == 'false') {
                closeLoading();
                layer.alert("您无权对当前数据操作");
            }
        } catch (e) {

        }

    },
    timeout: 100000,
    error: function (event, jqXHR, ajaxSettings, thrownError) {
        closeLoading();
        var status = event.status;
        var statusText = event.statusText;
        if (statusText == 'timeout') {
            alertErrorInfo('request ' + statusText);
        } else {
            alertErrorInfo(event.responseText);
        }
    }
});

function alertErrorInfo(error) {
    layer.open({
        type: 1,
        title: '错误信息',
        shadeClose: false,
        shade: [0.7],
        maxmin: true, //开启最大化最小化按钮
        area: ['1000px', '655px'],
        content: "<div>" + error + "</div>"
    })
}

var currentLoading = null;

function loading() {
    currentLoading = layer.load(0, {shade: [0.5, "#fff"]});
}

function closeLoading() {
    layer.closeAll();
}

function closeCurrentLoading() {
    layer.close(currentLoading);
}

function fmtDate(date) {
    if (!date) {
        return "";
    }
    var date = new Date(date);
    var y = 1900 + date.getYear();
    var m = "0" + (date.getMonth() + 1);
    var d = "0" + date.getDate();
    return y + "-" + m.substring(m.length - 2, m.length) + "-" + d.substring(d.length - 2, d.length);
}

function fmtDate2(date) {
    if (!date) {
        return "";
    }
    var date = new Date(date);
    var y = 1900 + date.getYear();
    var m = "0" + (date.getMonth() + 1);
    var d = "0" + date.getDate();
    var h = "0" + date.getHours();
    var mm = "0" + date.getMinutes();
    var s = "0" + date.getSeconds();
    return y + "-" + m.substring(m.length - 2, m.length) + "-" + d.substring(d.length - 2, d.length) + " " + h.substring(h.length - 2, h.length) + ":" + mm.substring(mm.length - 2, mm.length) + ":" + s.substring(s.length - 2, s.length);
}


function numJy(obj) {
    obj.value = obj.value.replace(/[^\d]/g, '');
}

function ajaxFileUpload(id, thisId, preview) {
    var fileFields = $("#" + thisId).val();
    if (fileFields != null && fileFields != undefined && fileFields != '') {
        var n = fileFields.lastIndexOf(".");
        var str = fileFields.substring(n + 1);
        if (str != "jpeg" && str != "JPEG" && str != "jpg" && str != "pdf" && str != "gif" && str != "bmp" && str != "png" && str != "JPG" && str != "PNG" && str != "GIF" && str != "BMP") {
            layer.alert("请选择正确格式的图片!");
            return;
        }
    } else {
        layer.alert("请选择要上传的图片");
        return;
    }

    var image = document.getElementById(thisId).files[0];
    var formData = new FormData();
    formData.append("file", image);
    loading();
    $.ajax({
        url: base + "/img/uploadImg.do",
        type: 'POST',
        dataType: "json",
        data: formData,
        async: false,
        cache: false,
        contentType: false,
        processData: false,
        success: function (data) {
            closeCurrentLoading();
            if (data.success) {
                var url = data.imageUrl;
                $("#" + id).val(data.imageUrl);
                $("#" + preview).attr("src", "");
                if (url.length == 0) {
                    layer.alert("请上传图片")
                } else {
                    $("#" + preview).attr("src", url);
                }
            } else {
                layer.alert(data.message);
            }
        }
    });
}

function ajaxApkFileUpload(id, thisId) {
    var fileFields = $("#" + thisId).val();
    if (fileFields != null && fileFields != undefined && fileFields != '') {
        var n = fileFields.lastIndexOf(".");
        var str = fileFields.substring(n + 1);
        if (str != "apk") {
            layer.alert("请上传apk文件!");
            $("#" + thisId).val("");
            return;
        }
    } else {
        layer.alert("请选择要上传的图片");
        return;
    }

    var apk = document.getElementById(thisId).files[0];
    var formData = new FormData();
    formData.append("fileApk", apk);
    loading();
    $.ajax({
        url: base + "/img/uploadApk.do",
        type: 'POST',
        dataType: "json",
        data: formData,
        async: false,
        cache: false,
        contentType: false,
        processData: false,
        success: function (data) {
            closeCurrentLoading();
            if (data.success) {
                var url = data.url;
                $("#" + id).val(url);
                if (url.length == 0) {
                    layer.alert("请上传图片")
                }
            } else {
                layer.alert(data.message);
            }
        }
    });
}

function getBootstrapTableHeight() {
    var navHeight = $("#navp").height();
    var height = document.body.scrollHeight;
    if (height < navHeight) {
        height = navHeight - 170;
    } else {
        height = (height - 200);
    }
    return height;
}



